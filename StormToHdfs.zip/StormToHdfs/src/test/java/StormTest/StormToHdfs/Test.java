package StormTest.StormToHdfs;

import java.util.HashMap;
import java.util.Map;

public class Test {
	public static void main(String[] args) {
		Map<String, String> maop  = new HashMap<String, String>();
		for (int i = 0; i < 10; i++) {
			maop.put("KeeNum" + i, "i" + i);
			i += 2;
		}
		
		for (String key : maop.keySet()) {
			   System.out.println("key= "+ key + " and value= " + maop.get(key));
	    }
	}
}
