package com.redis.test;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

public class JmeterRedisTest extends AbstractJavaSamplerClient {
	static JedisCluster jc;
	static JedisClusterPoolFactory jf;

	public Arguments getDefaultParameters() {
		// TODO Auto-generated method stub
		Arguments params = new Arguments();
		params.addArgument("batchSize", "1000");
		params.addArgument("byte", "2048");
		return params;
	}

	public void setupTest(JavaSamplerContext context) {
		try {
			jc = jf.getJedisCluster();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void teardownTest(JavaSamplerContext context) {
		try {
			jc.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public SampleResult runTest(JavaSamplerContext arg0) {
		SampleResult sr = new SampleResult();
		sr.setSampleLabel("Java request");
		sr.sampleStart();// jmeter
		for (int i = 0; i < arg0.getIntParameter("batchSize"); i++) {
			jc.set(i+"", "aaa");
		}
		sr.setSuccessful(true);
		sr.sampleEnd();
		return sr;
	}

}
