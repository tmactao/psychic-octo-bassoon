package com.redis.test;

import redis.clients.jedis.Jedis;

public class JedisPoolTest {
	public static void main(String[] args) {
		RedisUtil ruUtil = new RedisUtil();
		Jedis jC = ruUtil.getJedis();
		long start = System.currentTimeMillis();
		for (int i = 0; i < 10000; i++) {
			jC.select(2);
			jC.set("key : "+i, "value : " + i + 1);
		}
		long end = System.currentTimeMillis();
		System.out.println("time : " + (end - start));
	}

}
