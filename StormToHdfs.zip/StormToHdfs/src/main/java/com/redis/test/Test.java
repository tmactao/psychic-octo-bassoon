package com.redis.test;

import java.util.HashSet;
import java.util.Set;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

public class Test {
	public static void main(String[] args) {
		Set<HostAndPort> jedisClusterNodes = new HashSet<HostAndPort>();  
        //Jedis Cluster will attempt to discover cluster nodes automatically  
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6379));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6379));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6379));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6379));
		
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6380));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6380));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6380));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6380));
		
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6381));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6381));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6381));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6381));
		
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6382));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6382));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6382));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6382));
		
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6383));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6383));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6383));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6383));
		
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6384));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6384));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6384));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6384));
		
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6385));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6385));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6385));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6385));
		
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6386));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6386));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6386));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6386));  
		
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6387));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6387));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6387));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6387));
		
		jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6788));
		jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6788));
		jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6788));
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6788));         
        JedisCluster jc = new JedisCluster(jedisClusterNodes);  
         
//        for (int i = 0; i < 1000; i++) {
//        	jc.set("foo"+i, "bar"+i);//不设置超时  
//        	jc.setex("foo"+i+1,1800, "bar"+i+1);//设置1800s超时  
//			
//		}
//          
        
//        Person p = new Person();  
        long start = System.currentTimeMillis();
        Person[] pa = new Person[1000];
        for (int i = 0; i < pa.length; i++) {
			jc.set(pa[i].toString(), pa[i+1].toString());
		}
        long end = System.currentTimeMillis();
        System.out.println("time is : " + (end-start)); 
//        p.setName("DeanPhipray");  
//        p.setGender("M");  
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();  
//        try{  
//            ObjectOutputStream oos = new ObjectOutputStream(baos);  
//            oos.writeObject(p);  
//            oos.flush();  
//         
//        jc.set("fooMap".getBytes(), baos.toByteArray());  
//        jc.setex("fooMap".getBytes(), 1800, baos.toByteArray());  
          
//        String value = jc.get("foo1");  
//        System.out.println("foo1=========="+ value);  
      
//        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(jc.get("fooMap".getBytes())));  
//        Person  pr = (Person) in.readObject();   
//          
//        System.out.println("再次为人"+ pr.getName()+"+++"+pr.getGender());  
          
//    } catch (Exception e) {  
//             //do something     
//            e.printStackTrace();  
//    }   
          
          
          
    }  
      
      
}  