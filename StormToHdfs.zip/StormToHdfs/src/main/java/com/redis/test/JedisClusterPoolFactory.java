package com.redis.test;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

public class JedisClusterPoolFactory {

	private GenericObjectPool<Object> pool;

	public JedisClusterPoolFactory(GenericObjectPoolConfig config) throws Exception {
		ConnectionFactory factory = new ConnectionFactory();
		pool = new GenericObjectPool<Object>(factory, config);
		init();
	}

	public JedisCluster getJedisCluster() throws Exception {
		return (JedisCluster) pool.borrowObject();
	}

	class ConnectionFactory extends BasePooledObjectFactory<Object> {

		@Override
		public Object create() throws Exception {
			Set<HostAndPort> jedisClusterNodes = new HashSet<HostAndPort>();  
	        //Jedis Cluster will attempt to discover cluster nodes automatically  
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6379));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6379));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6379));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6379));
			
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6380));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6380));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6380));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6380));
			
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6381));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6381));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6381));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6381));
			
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6382));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6382));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6382));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6382));
			
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6383));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6383));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6383));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6383));
			
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6384));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6384));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6384));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6384));
			
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6385));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6385));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6385));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6385));
			
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6386));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6386));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6386));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6386));  
			
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6387));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6387));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6387));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6387));
			
			jedisClusterNodes.add(new HostAndPort("10.1.4.213", 6788));
			jedisClusterNodes.add(new HostAndPort("10.1.4.214", 6788));
			jedisClusterNodes.add(new HostAndPort("10.1.4.215", 6788));
			jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6788));         
	        JedisCluster jc = new JedisCluster(jedisClusterNodes);   
			return jc;
		}

		@Override
		public PooledObject<Object> wrap(Object arg0) {
			return new DefaultPooledObject<Object>(arg0);
		}

	}

	public JedisClusterPoolFactory init() throws Exception {
		GenericObjectPoolConfig conf = new GenericObjectPoolConfig();
		conf.setTestWhileIdle(true);
		conf.setMinEvictableIdleTimeMillis(60000);
		conf.setTimeBetweenEvictionRunsMillis(30000);
		conf.setNumTestsPerEvictionRun(-1);
		conf.setMaxTotal(1000);
		conf.setMaxIdle(1000);
		conf.setMaxWaitMillis(5000);
		conf.setTestOnBorrow(true);
		JedisClusterPoolFactory poolFactory = new JedisClusterPoolFactory(conf);
		return poolFactory;
	}
	
	public void releaseConnection(JedisCluster jc) {
		try {
			pool.returnObject(jc);
		} catch (Exception e) {
			if (jc != null) {
				try {
					jc.close();
				} catch (Exception ex) {
					//
				}
			}
		}
	}
}
