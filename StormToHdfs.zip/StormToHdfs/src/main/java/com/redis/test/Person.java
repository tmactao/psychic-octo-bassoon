package com.redis.test;

public class Person {
	public String name;
	public String gender;
	
	public Person() {
		// TODO Auto-generated constructor stub
		this.name = "aaa";
		this.gender = "m";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	 
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
}
