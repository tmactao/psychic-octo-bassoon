package com.redis.ss;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.redis.test.RedisUtil;

/**
 * @author : jiangtao
 * @ClassName : RedisManager
 * @Description : redis数据源操作类
 * @email : jiangtao@zork.com.cn
 */
public class RedisManager {

	/**
	 * @param mapValue
	 * @throws @Title:
	 *             mSetRedis
	 * @Description: 插入多条数据入库
	 */
	public static boolean mSetRedis(Map<String, String> mapValue) {
		// 拿到传来的map.size()，转成相应的数组批量set redis数据库
		boolean ret = false;
		Jedis jedis = RedisUtil.getJedis();
		String[] strings = new String[mapValue.size() << 1];

		try {
			int i = 0;
			for (String key : mapValue.keySet()) {
				strings[i] = key;
				strings[i + 1] = mapValue.get(key);
				i = i + 2;
			}
			// 批量插入
			jedis.mset(strings);
			ret = true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("批量插入异常");
		} finally {
			RedisUtil.free(jedis);
		}

		System.out.println("批量插入结束,插入条数:" + mapValue.size());
		return ret;
	}

	/**
	 * @param monLists
	 *            封装一个对象，list写入
	 * @return boolean
	 * @throws @Title:
	 *             mSetRedis
	 * @Description: 批量插入多条数据
	 */
	public static boolean mSetRedis(List<Monitor> monLists) {
		boolean ret = false;
		Jedis jedis = RedisUtil.getJedis();
		String[] strings = new String[monLists.size() * 2];

		int j = 0;
		for (int i = 0; i < strings.length; i += 2) {
			strings[i] = monLists.get(j).getKey();
			strings[i + 1] = monLists.get(j).getValue();
			j++;
		}
		try {
			jedis.mset(strings);
			ret = true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("批量插入异常，" + e.getMessage());
		} finally {
			RedisUtil.free(jedis);
		}
		return ret;
	}

	/**
	 * 写入到指定的数据库;数据库索引默认[0~15]
	 * 
	 * @param monLists
	 *            封装一个对象，list写入
	 * @param dbindex
	 *            数据库索引
	 * @return boolean
	 * @throws @Title:
	 *             mSetRedis
	 * @Description: 批量插入多条数据
	 */
	public static boolean mSetRedis(List<Monitor> monLists, int dbindex) {
		boolean ret = false;
		Jedis jedis = RedisUtil.getJedis();
		jedis.select(dbindex);
		String[] strings = new String[monLists.size() * 2];

		int j = 0;
		for (int i = 0; i < strings.length; i += 2) {
			strings[i] = monLists.get(j).getKey();
			strings[i + 1] = monLists.get(j).getValue();
			j++;
		}
		try {
			jedis.mset(strings);
			ret = true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("批量插入异常，" + e.getMessage());
		} finally {
			RedisUtil.free(jedis);
		}
		return ret;
	}

	/**
	 * @param pattern
	 * @return List<String>
	 * @throws @Title:
	 *             mGetValue
	 * @Description: 查询多条数据
	 */
	public static List<String> mGetKeys(String pattern) {
		Jedis jedis = RedisUtil.getJedis();
		List<String> keyList = new ArrayList<String>();
		try {
			keyList.addAll(jedis.keys(pattern));
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("匹配key值失败，" + e.getMessage());
		} finally {
			RedisUtil.free(jedis);
		}

		System.out.println("组装key值方法结束，获取key值数量:" + keyList.size());
		return keyList;
	}

	/**
	 * @param pattern
	 * @return List<String>
	 * @throws @Title:
	 *             mGetValue
	 * @Description: 查询多条数据
	 */
	public static List<String> mGetKeys(String pattern, int dbindex) {
		Jedis jedis = RedisUtil.getJedis();
		jedis.select(dbindex);
		List<String> keyList = new ArrayList<String>();
		try {
			keyList.addAll(jedis.keys(pattern));
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("匹配key值失败，" + e.getMessage());
		} finally {
			RedisUtil.free(jedis);
		}

		System.out.println("组装key值方法结束，获取key值数量:" + keyList.size());
		return keyList;
	}

	/**
	 * 从db0数据库查询数据,如果查询的key位于其它dbX数据库,则返回null 获取指定key的数据
	 * 
	 * @param key
	 *            key值
	 * @return
	 */
	public static String mGetValue(String key) {
		String ret = null;
		Jedis jedis = RedisUtil.getJedis();
		jedis.select(0);
		try {
			ret = jedis.get(key);
		} catch (Exception e) {
			System.out.println("查询失败，" + e.getMessage());
			e.printStackTrace();
		} finally {
			RedisUtil.free(jedis);
		}
		return ret;
	}

	/**
	 * 从指定的数据库查询指定key的value数据/dbx 获取指定key的数据
	 * 
	 * @param key
	 *            key值
	 * @return
	 */
	public static String mGetValue(String key, int dbindex) {
		String ret = null;
		Jedis jedis = RedisUtil.getJedis();
		jedis.select(dbindex);

		try {
			ret = jedis.get(key);
		} catch (Exception e) {
			System.out.println("查询失败，" + e.getMessage());
			e.printStackTrace();
		} finally {
			RedisUtil.free(jedis);
		}
		return ret;
	}

	/**
	 * 删除当前选择数据库中所有的key
	 * 
	 * @param dbindex
	 */
	public static void flushDB(int dbindex) {
		Jedis jedis = RedisUtil.getJedis();
		jedis.select(dbindex);
		try {
			jedis.flushDB();
		} finally {
			RedisUtil.free(jedis);
		}
	}

	/**
	 * @Title:batchinsert
	 * @Description:  基于redis管道的数据插入,建议这种方式, dbindex默认[0~15]
	 * @param monLists  封装一个对象，list写入
	 * @return boolean
	 * @throws 
	 * 
	 */
	public static boolean batchinsert(List<Monitor> monLists,int dbindex) {


        boolean ret = false;
		Jedis jedis = null;
		try{
			jedis = RedisUtil.getJedis();
			jedis.select(dbindex);
			Pipeline p = jedis.pipelined();

		    for(int i=0;i<monLists.size();i++){
		         p.set(monLists.get(i).getKey(), monLists.get(i).getValue());
		    }
		    p.sync(); // 这段代码获取所有的response			
			ret = true;
		}catch(Exception ex){
			  ex.printStackTrace();
			  System.out.println("批量插入异常，" + ex.getMessage());
		}finally{
			monLists.clear();
			RedisUtil.free(jedis);
		}
	     return ret;
		
	}

}
