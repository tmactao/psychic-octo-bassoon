package com.redis.ss;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.redis.test.RedisUtil;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;

public class Test {
	static Jedis jedis;
	public static void main(String[] args) {
		Set<HostAndPort> jedisClusterNodes = new HashSet<HostAndPort>();  
		jedisClusterNodes.add(new HostAndPort("10.1.4.216", 6788));         
        JedisCluster jc = new JedisCluster(jedisClusterNodes);  
         
        jedis = RedisUtil.getJedis();
        RedisManager rm = new RedisManager();
        List<Monitor> monLists = new ArrayList<Monitor>();
        for (int i = 0; i < args.length; i++) {
			
		}
        rm.batchinsert(monLists, 0);
    }  
}  