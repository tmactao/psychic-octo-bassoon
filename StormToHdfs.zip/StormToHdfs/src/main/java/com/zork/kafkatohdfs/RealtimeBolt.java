package com.zork.kafkatohdfs;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Tuple;

public class RealtimeBolt extends BaseRichBolt {

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = 1075501260517004798L;
	private static final Log LOG = LogFactory.getLog(RealtimeBolt.class);
	private OutputCollector collector;
	public void execute(Tuple tuple) {
		// TODO Auto-generated method stub
		String line = tuple.getString(0).trim();
		LOG.info("REALTIME: " + line);
		collector.ack(tuple);
	}

	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		// TODO Auto-generated method stub
		this.collector = collector;
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub

	}

}
