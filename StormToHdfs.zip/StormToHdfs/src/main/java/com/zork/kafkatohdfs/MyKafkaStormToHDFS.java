package com.zork.kafkatohdfs;

import java.util.Arrays;

import org.apache.storm.hdfs.bolt.HdfsBolt;
import org.apache.storm.hdfs.bolt.format.DefaultFileNameFormat;
import org.apache.storm.hdfs.bolt.format.DelimitedRecordFormat;
import org.apache.storm.hdfs.bolt.format.FileNameFormat;
import org.apache.storm.hdfs.bolt.format.RecordFormat;
import org.apache.storm.hdfs.bolt.rotation.FileRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.TimedRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.TimedRotationPolicy.TimeUnit;
import org.apache.storm.hdfs.bolt.sync.CountSyncPolicy;
import org.apache.storm.hdfs.bolt.sync.SyncPolicy;

import com.zork.tohdfs.KafkaWordSplitter;
import com.zork.tohdfs.MyKafkaTopo;
import com.zork.tohdfs.WordCounter;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.AuthorizationException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.spout.SchemeAsMultiScheme;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;
import storm.kafka.BrokerHosts;
import storm.kafka.KafkaSpout;
import storm.kafka.SpoutConfig;
import storm.kafka.StringScheme;
import storm.kafka.ZkHosts;

public class MyKafkaStormToHDFS {
	public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException, AuthorizationException, InterruptedException {
		String zks = "zork-2:2181,zork-3:2181,zork-4:2181";
		String topic = "kafkastormtest";
		String zkRoot = "/storm";
		String id = "hdfs";
		
		BrokerHosts brokerHosts = new ZkHosts(zks);
		SpoutConfig spoutConfig = new SpoutConfig(brokerHosts, topic, zkRoot, id);
		spoutConfig.scheme = new SchemeAsMultiScheme(new StringScheme());
		spoutConfig.zkServers = Arrays.asList(new String[] {"zork-2", "zork-3", "zork-4"});
		spoutConfig.zkPort = 2181;
		
		RecordFormat format = new DelimitedRecordFormat().withFieldDelimiter("@");
		SyncPolicy syncPolicy = new CountSyncPolicy(1000);
		FileRotationPolicy rotationPolicy = new TimedRotationPolicy(1.0f, TimeUnit.MINUTES);
		
		FileNameFormat fileNameFormat = new DefaultFileNameFormat().withPath("/kafkatestjiang/").withPrefix("app_").withExtension(".log");
		
		HdfsBolt hdfsBolt = new HdfsBolt()
				.withFsUrl("hdfs://zork-1:8020")
				.withFileNameFormat(fileNameFormat)
				.withRecordFormat(format)
				.withRotationPolicy(rotationPolicy)
				.withSyncPolicy(syncPolicy);
		
	    TopologyBuilder builder = new TopologyBuilder();
        builder.setSpout("kafka-reader", new KafkaSpout(spoutConfig), 3); // Kafka我们创建了一个3分区的Topic，这里并行度设置为3
        builder.setBolt("to-upper", new KafkaWordToUpper(), 2).shuffleGrouping("kafka-reader");
        builder.setBolt("hdfs-bolt", hdfsBolt, 2).shuffleGrouping("to-upper");
        builder.setBolt("realtime", new RealtimeBolt(),2).shuffleGrouping("to-upper");
        
        Config conf = new Config();
        String name = MyKafkaStormToHDFS.class.getSimpleName();
        if (args != null && args.length > 0) {
			conf.put(Config.NIMBUS_HOST, args[0]);
			conf.setNumWorkers(3);
			StormSubmitter.submitTopologyWithProgressBar(name, conf, builder.createTopology());
		}else {
			conf.setMaxTaskParallelism(3);
			LocalCluster cluster = new LocalCluster();
			cluster.submitTopology(name, conf, builder.createTopology());
			Thread.sleep(60000);
			cluster.shutdown();
		}
	}
}
