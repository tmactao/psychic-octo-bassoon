package com.zork.stormtohdfs;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichSpout;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;
import backtype.storm.utils.Utils;
/**
 * 
* @ClassName : EvenSpout
* @Description : TODO
* @author : jiangtao
* @email : jiangtao@zork.com.cn
 */
public class EvenSpout extends BaseRichSpout{

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = 2958653626709057557L;
	private static final Log LOG = LogFactory.getLog(EvenSpout.class);
	private SpoutOutputCollector collector;
	private Random random;
	private String[] records;
	
	public void nextTuple() {
		// TODO Auto-generated method stub
		Utils.sleep(1000);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		Date date = new Date(System.currentTimeMillis());
		String minute = df.format(date);
		String record = records[random.nextInt(records.length)];
		LOG.info("EMIT[spout -> hdfs] " + minute + " : " + record);
		System.out.println("spout发送数据到hdfs的时间和记录数: " + minute + " : " + record); 
		collector.emit(new Values(minute, record));
	}

	public void open(Map stormConf, TopologyContext context, SpoutOutputCollector collector) {
		// TODO Auto-generated method stub
		this.collector = collector;
		random = new Random();
		records = new String[] {
                     "10001     ef2da82d4c8b49c44199655dc14f39f6     4.2.1     HUAWEI G610-U00     HUAWEI     2     70:72:3c:73:8b:22     2016-04-21 12:36:35",
                     "10001     ffb52739a29348a67952e47c12da54ef     4.3     GT-I9300     samsung     2     50:CC:F8:E4:22:E2     2016-04-21 12:36:02",
                     "10001     ef2da82d4c8b49c44199655dc14f39f6     4.2.1     HUAWEI G610-U00     HUAWEI     2     70:72:3c:73:8b:22     2016-04-21 12:36:35"
       };

	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		declarer.declare(new Fields("minute", "record"));
	}

}
