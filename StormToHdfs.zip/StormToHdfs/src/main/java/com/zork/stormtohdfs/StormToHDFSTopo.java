package com.zork.stormtohdfs;

import org.apache.storm.hdfs.bolt.HdfsBolt;
import org.apache.storm.hdfs.bolt.format.DefaultFileNameFormat;
import org.apache.storm.hdfs.bolt.format.DelimitedRecordFormat;
import org.apache.storm.hdfs.bolt.format.FileNameFormat;
import org.apache.storm.hdfs.bolt.format.RecordFormat;
import org.apache.storm.hdfs.bolt.rotation.FileRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.TimedRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.TimedRotationPolicy.TimeUnit;
import org.apache.storm.hdfs.bolt.sync.CountSyncPolicy;
import org.apache.storm.hdfs.bolt.sync.SyncPolicy;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.AuthorizationException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;
/**
 * 
* @ClassName : StormToHDFSTopo
* @Description : 数据写入到hdfs
* @author : jiangtao
* @email : jiangtao@zork.com.cn
 */
public class StormToHDFSTopo {
	public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException, AuthorizationException, InterruptedException {
		RecordFormat format = new DelimitedRecordFormat().withFieldDelimiter(" : ");
		SyncPolicy syncPolicy = new CountSyncPolicy(1000);
		FileRotationPolicy rotationPolicy = new TimedRotationPolicy(1.0f, TimeUnit.MINUTES);
		
		FileNameFormat fileNameFormat = new DefaultFileNameFormat().withPath("/storm/").withPrefix("app_").withExtension(".log");
		
		HdfsBolt hdfsBolt = new HdfsBolt()
				.withFsUrl("hdfs://zork-1:8020")
				.withFileNameFormat(fileNameFormat)
				.withRecordFormat(format)
				.withRotationPolicy(rotationPolicy)
				.withSyncPolicy(syncPolicy);
		
		TopologyBuilder builder = new TopologyBuilder();
		builder.setSpout("event-spout", new EvenSpout(),3);
		builder.setBolt("hdfs-bolt", hdfsBolt,2).fieldsGrouping("event-spout", new Fields("minute"));
		
		Config config = new Config();
		String name = StormToHDFSTopo.class.getSimpleName();
		if (args != null && args.length > 0) {
			config.put(Config.NIMBUS_HOST, args[0]);
			config.setNumWorkers(3);
			StormSubmitter.submitTopologyWithProgressBar(name, config, builder.createTopology());
		}else {
			config.setMaxTaskParallelism(3);
			LocalCluster cluster = new LocalCluster();
			cluster.submitTopology(name, config, builder.createTopology());
			Thread.sleep(60000);
			cluster.shutdown();
		}
		
	}
}
