package com.zork.tohdfs;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;

public class WordCounter extends BaseRichBolt {

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = 1L;
	private static final Log LOG = LogFactory.getLog(WordCounter.class);
	private OutputCollector collector;
	private Map<String, AtomicInteger> counterMap;
	
	public void execute(Tuple tuple) {
		// TODO Auto-generated method stub
		String word = tuple.getString(0);
		int count = tuple.getInteger(1);
		LOG.info("RECV[splitter -> counter] " + word + " : " + count);
		System.out.println("拆分单词： " + word + " : " + count);
		AtomicInteger ai = this.counterMap.get(word);
		if (ai == null) {
			ai = new AtomicInteger();
			this.counterMap.put(word, ai);
		}
		ai.addAndGet(count);
		collector.ack(tuple);
		LOG.info("CHECK statistics map: " + this.counterMap);
		System.out.println("输出 map是: " + this.counterMap);
	}

	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		// TODO Auto-generated method stub
		this.collector = collector;
		this.counterMap = new HashMap<String, AtomicInteger>();
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		declarer.declare(new Fields("word", "count"));
	}
	
	@Override
	public void cleanup() {
		// TODO Auto-generated method stub
		LOG.info("The final result:");
		Iterator<Entry<String, AtomicInteger>> iterator = this.counterMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<String, AtomicInteger> entry = iterator.next();
			LOG.info(entry.getKey() + "\t:\t" + entry.getValue().get());
		}
	}

}
