package com.zork.tohdfs;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;

import backtype.storm.topology.BasicOutputCollector;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseBasicBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

/**
 * 
* @ClassName : SenqueceBolt
* @Description : 实现很简单，在接收的spout的消息，分成相应的字段
* @author : jiangtao
* @email : jiangtao@zork.com.cn
 */
public class SenqueceBolt extends BaseBasicBolt {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<Field> fields;
    private int length = 0;
    
	public void execute(Tuple input, BasicOutputCollector collector) {
		// TODO Auto-generated method stub
		String zorkjson = JSONUtils.ReadJsonFile("src/main/java/com/zork/tohdfs/jiangtao.avsc");
		Schema schema = null;
		length = fields.size();
	    try {
			schema = new Schema.Parser().parse(zorkjson);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    DatumReader<GenericRecord> reader=new GenericDatumReader<GenericRecord>(schema);  
		String word = (String) input.getValue(0);
		InputStream inputStream = new ByteArrayInputStream(word.getBytes());
		Decoder decoder = DecoderFactory.get().binaryDecoder(inputStream,null);  
		GenericRecord result = null;
		try {
			result = reader.read(null,decoder);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
	    String begtime = "";
		String endtime = "";
		String name = "";
		String age = "";
		String grade ="";
		
		if (result.get("begtime") != null
			 && result.get("begtime").toString().trim().length() > 0) {
			 result.get("begtime").toString();
		 }
			
		 if (result.get("endtime") != null
			 && result.get("endtime").toString().trim().length() > 0) {
			 result.get("endtime").toString();
		 }
			
		 if (result.get("name") != null
			 && result.get("name").toString().trim().length() > 0) {
			 result.get("name").toString();
		 }
			
		 if (result.get("age") != null
			 && result.get("age").toString().trim().length() > 0) {
			 result.get("age").toString();
		 }
			
		 if (result.get("grade") != null
			 && result.get("grade").toString().trim().length() > 0) {
			 result.get("grade").toString();
		 }
		 
		collector.emit(new Values(begtime,endtime,name,age,grade));

		}
	
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		declarer.declare(new Fields("begtime","endtime","name","age","grade"));
	}

}
