package com.zork.tohdfs;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

public class KafkaWordSplitter extends BaseRichBolt{

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = 1L;
	private static final Log LOG = LogFactory.getLog(KafkaWordSplitter.class);
	private OutputCollector collector;
	
	public void execute(Tuple tuple) {
		// TODO Auto-generated method stub
		String line = tuple.getString(0);
		LOG.info("RECV[kafka -> splitter] " + line);
		System.out.println("打印结果,输出行数 ： " + line);
//		String[] words = line.split("\\s+");
		String[] words = line.split("@");
		for (String word : words) {
			LOG.info("EMIT[splitter -> counter] " + word);
			System.out.println("打印结果,输出单词: " + word);
			collector.emit(tuple, new Values(word, 1));
		}
	}

	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		// TODO Auto-generated method stub
		this.collector = collector;
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		declarer.declare(new Fields("word", "count"));
	}

}
