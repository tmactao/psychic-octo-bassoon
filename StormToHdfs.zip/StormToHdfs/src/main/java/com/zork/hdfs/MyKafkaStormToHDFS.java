package com.zork.hdfs;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.storm.hdfs.bolt.HdfsBolt;
import org.apache.storm.hdfs.bolt.format.DefaultFileNameFormat;
import org.apache.storm.hdfs.bolt.format.DelimitedRecordFormat;
import org.apache.storm.hdfs.bolt.format.FileNameFormat;
import org.apache.storm.hdfs.bolt.format.RecordFormat;
import org.apache.storm.hdfs.bolt.rotation.FileRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.TimedRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.TimedRotationPolicy.TimeUnit;
import org.apache.storm.hdfs.bolt.sync.CountSyncPolicy;
import org.apache.storm.hdfs.bolt.sync.SyncPolicy;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.AuthorizationException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.spout.SchemeAsMultiScheme;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;
import storm.kafka.BrokerHosts;
import storm.kafka.KafkaSpout;
import storm.kafka.SpoutConfig;
import storm.kafka.StringScheme;
import storm.kafka.ZkHosts;

public class MyKafkaStormToHDFS {
	public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException, AuthorizationException, InterruptedException {
		String zks = "zork-2:2181,zork-3:2181,zork-4:2181";
		String topic = "kafkastormtest";
//		String topic = "taotest";
		String zkRoot = "/storm";
		String id = "dd";
		
		BrokerHosts brokerHosts = new ZkHosts(zks);
		SpoutConfig spoutConfig = new SpoutConfig(brokerHosts, topic, zkRoot, id);
		spoutConfig.scheme = new SchemeAsMultiScheme(new StringScheme());
		spoutConfig.zkServers = Arrays.asList(new String[] {"zork-2", "zork-3", "zork-4"});
		spoutConfig.zkPort = 2181;
		
		RecordFormat format = new DelimitedRecordFormat().withFieldDelimiter("@");
		SyncPolicy syncPolicy = new CountSyncPolicy(1000);
		
//		可以设置在满足什么条件下，切出一个新的日志，如可以指定多长时间切出一个新的日志文件，
//		可以指定一个日志文件大小达到设置值后，再写一个新日志文件
		FileRotationPolicy rotationPolicy = new TimedRotationPolicy(1.0f, TimeUnit.MINUTES);
//		FileRotationPolicy rotationPolicyFilesize = new FileSizeRotationPolicy(128.0f, Units.MB);
		
		FileNameFormat fileNameFormat = new DefaultFileNameFormat().withPath("/jiangtao/").withPrefix("app_").withExtension(".txt");
		
		HdfsBolt hdfsBolt = new HdfsBolt()
				.withFsUrl("hdfs://zork-1:8020")
				.withFileNameFormat(fileNameFormat)
				.withRecordFormat(format)
				.withRotationPolicy(rotationPolicy)
				.withSyncPolicy(syncPolicy);
		
	    TopologyBuilder builder = new TopologyBuilder();
        builder.setSpout("_reader", new KafkaSpout(spoutConfig), 3); 
        builder.setBolt("_senquece", new SenqueceBolt()).shuffleGrouping("_reader"); 
        builder.setBolt("_hdfs", hdfsBolt, 3).shuffleGrouping("_senquece"); 
        
        Config conf = new Config();
        Map<String, String> map = new HashMap<String, String>(); 
        // 配置Kafka broker地址       
        map.put("metadata.broker.list", "zork-2:9092,zork-3:9092,zork-4:9092");
        // serializer.class为消息的序列化类
        map.put("serializer.class", "kafka.serializer.StringEncoder");
        conf.put("kafka.broker.properties", map);

        conf.setDebug(true);
        String name = MyKafkaStormToHDFS.class.getSimpleName();
        if (args != null && args.length > 0) {
			conf.put(Config.NIMBUS_HOST, args[0]);
			conf.setNumWorkers(3);
			StormSubmitter.submitTopologyWithProgressBar(name, conf, builder.createTopology());
		}else {
			conf.setMaxTaskParallelism(3);
			LocalCluster cluster = new LocalCluster();
			cluster.submitTopology(name, conf, builder.createTopology());
			Thread.sleep(6000000);
			cluster.shutdown();
		}
	}
}
