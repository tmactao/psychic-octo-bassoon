package com.zork.tomysql;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;
/**
 * 
* @ClassName : WordNormalizerBolt
* @Description : TODO
* @author : jiangtao
* @email : jiangtao@zork.com.cn
 */
public class WordNormalizerBolt extends BaseRichBolt{

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = -2138746074773091709L;
	private OutputCollector collector;
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void execute(Tuple tuple) {
		// TODO Auto-generated method stub
		String sentence = tuple.getString(0);
		String[] words = sentence.split("@");
		for (String word : words) {
			System.out.println("word : " + word);
			word = word.trim();
			if (!word.isEmpty()) {
				word = word.toUpperCase();
				List strs = new ArrayList();
				strs.add(tuple);
				collector.emit(strs,new Values(word));
			}
		}
		collector.ack(tuple);
	}

	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		// TODO Auto-generated method stub
		this.collector = collector;
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		declarer.declare(new Fields("word"));
	}

}
