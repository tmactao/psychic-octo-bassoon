package com.zork.tomysql;

import java.util.Arrays;

import com.zork.kafkatohdfs.MyKafkaStormToHDFS;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.AuthorizationException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.spout.SchemeAsMultiScheme;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;
import storm.kafka.BrokerHosts;
import storm.kafka.KafkaSpout;
import storm.kafka.SpoutConfig;
import storm.kafka.StringScheme;
import storm.kafka.ZkHosts;
/**
 * 
* @ClassName : KafkaToMysqlTopo
* @Description : 统计词频写入到MySQL中
* @author : jiangtao
* @email : jiangtao@zork.com.cn
 */
public class KafkaToMysqlTopo {
	public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException, AuthorizationException, InterruptedException {
		String zks = "zork-2:2181,zork-3:2181,zork-4:2181";
		String topic = "kafkaredis";
		String zkRoot = "/storm";
		String id = "12";
		
		BrokerHosts brokerHosts = new ZkHosts(zks);
		SpoutConfig spoutConfig = new SpoutConfig(brokerHosts, topic, zkRoot, id);
		spoutConfig.scheme = new SchemeAsMultiScheme(new StringScheme());
		spoutConfig.zkServers = Arrays.asList(new String[] {"zork-2", "zork-3", "zork-4"});
		spoutConfig.zkPort = 2181;
		
		TopologyBuilder builder = new TopologyBuilder();
		builder.setSpout("word-reader", new KafkaSpout(spoutConfig), 3);
		builder.setBolt("word-normalizer", new WordNormalizerBolt()).shuffleGrouping("word-reader");
		builder.setBolt("word-counter", new WordCounterBolt(), 1).fieldsGrouping("word-normalizer", new Fields("word"));
		
		Config conf = new Config();
        String name = KafkaToMysqlTopo.class.getSimpleName();
        if (args != null && args.length > 0) {
			conf.put(Config.NIMBUS_HOST, args[0]);
			conf.setNumWorkers(3);
			StormSubmitter.submitTopologyWithProgressBar(name, conf, builder.createTopology());
		}else {
			conf.setMaxTaskParallelism(3);
			LocalCluster cluster = new LocalCluster();
			cluster.submitTopology(name, conf, builder.createTopology());
			Thread.sleep(600000);
			cluster.shutdown();
		}
	}
}
