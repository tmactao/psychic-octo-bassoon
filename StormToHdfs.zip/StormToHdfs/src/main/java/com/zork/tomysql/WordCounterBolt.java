package com.zork.tomysql;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Tuple;
/**
 * 
* @ClassName : WordCounterBolt
* @Description : TODO
* @author : jiangtao
* @email : jiangtao@zork.com.cn
 */
public class WordCounterBolt extends BaseRichBolt{

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = -4194897405944935106L;
	Log LOG = LogFactory.getLog(WordCounterBolt.class);
	Integer id;
	String name;
	Map<String, Integer> counters;
	private OutputCollector collector;
	
	private static Connection getConn() {
	    String driver = "com.mysql.jdbc.Driver";
	    String url = "jdbc:mysql://10.176.3.101:3306/bigtest";
	    String username = "root";
	    String password = "admin123";
	    Connection conn = null;
	    try {
	        Class.forName(driver); //classLoader,加载对应驱动
	        conn = (Connection) DriverManager.getConnection(url, username, password);
	    } catch (ClassNotFoundException e) {
	        e.printStackTrace();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return conn;
	}
	
	private static int select(String word) {
	    Connection conn = getConn();
	    int count = 0;
	    String sqlStr = "select count from words where word='"+word+"'";
	    Statement statement;
	    try {
	    	System.out.println("method begin...");
	    	statement = (Statement) conn.createStatement();
	    	System.out.println("get statement...");
	        ResultSet rs = statement.executeQuery(sqlStr);
	        if(rs.next()){
	        	count = rs.getInt("count");
	        }
	        rs.close();
	        conn.close();
	    } catch (SQLException e) {
	    	System.out.println("查询失败" + e.getMessage());  
	    }
	    return count;
	}
	
	private static void update(String word, int value) {
	    Connection conn = getConn();
	    int i = 0;
	    String sqlStr = "update words set count = '"+value+"' where word = '"+word+"'";
	    Statement statement;
	    try {
	    	System.out.println("method begin...");
	    	statement = (Statement) conn.createStatement();
	    	System.out.println("get statement...");
	        i = statement.executeUpdate(sqlStr);
	        System.out.println("words表更新 " + i + " 条数据"); //输出插入操作的处理结果  
	        conn.close();
	    } catch (SQLException e) {
	    	System.out.println("更新数据失败" + e.getMessage());  
	    }
	}
	
	private static void insert(String word, int value) {
	    Connection conn = getConn();
	    int i = 0;
	    String sqlStr = "insert words(word,count) values('"+word+"','"+value+"')";
	    Statement statement;
	    try {
	    	System.out.println("method begin...");
	    	statement = (Statement) conn.createStatement();
	    	System.out.println("get statement...");
	        i = statement.executeUpdate(sqlStr);
	        System.out.println("向words表中插入 " + i + " 条数据"); //输出插入操作的处理结果  
	        conn.close();
	    } catch (SQLException e) {
	    	System.out.println("插入数据失败" + e.getMessage());  
	    }
	}
	
	public void execute(Tuple tuple) {
		// TODO Auto-generated method stub
		String strs = tuple.getString(0);
		if (!counters.containsKey(strs)) {
			counters.put(strs, 1);
		}else {
			Integer cc = counters.get(strs) + 1;
			counters.put(strs, cc);
		}
		
		for (Map.Entry<String, Integer> entry : counters.entrySet()) {
			int count = select(entry.getKey());
			if(count > 0) {
				update(entry.getKey(), entry.getValue());
			}else{
				insert(entry.getKey(), entry.getValue());
			}
		}
		collector.ack(tuple);
	}

	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		// TODO Auto-generated method stub
		this.collector = collector;
		this.counters = new HashMap<String, Integer>();
		this.name = context.getThisComponentId();
		this.id = context.getThisTaskId();
		
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
	}

}
