package com.zork.redis;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;
/**
 * 
* @ClassName : KafkaWordToUpper
* @Description : TODO
* @author : jiangtao
* @email : jiangtao@zork.com.cn
 */
public class KafkaWordToUpper extends BaseRichBolt {

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = -2304250047841793977L;
	private static final Log LOG = LogFactory.getLog(KafkaWordToUpper.class);
	private OutputCollector collector;
	
	public void execute(Tuple tuple) {
		// TODO Auto-generated method stub
		String line = tuple.getString(0).trim();
		LOG.info("RECV[kafka -> splitter] " + line);
		if (!line.isEmpty()) {
			String upperLine = line.toUpperCase();
			LOG.info("EMIT[splitter -> counter] " + upperLine);
			collector.emit(tuple, new Values(upperLine, upperLine.length()));
		}
		collector.ack(tuple);
	}

	public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
		// TODO Auto-generated method stub
		this.collector = collector;
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub
		declarer.declare(new Fields("line", "len"));
	}

}
