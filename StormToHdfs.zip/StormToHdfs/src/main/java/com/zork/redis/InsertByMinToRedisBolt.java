package com.zork.redis;


import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import backtype.storm.topology.BasicOutputCollector;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseBasicBolt;
import backtype.storm.tuple.Tuple;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;
/**
 * 
* @ClassName : InsertByMinToRedisBolt
* @Description : TODO
* @author : jiangtao
* @email : jiangtao@zork.com.cn
 */
public class InsertByMinToRedisBolt extends BaseBasicBolt {
	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = 867206279043213379L;
	private Jedis jedis;
	
	public void execute(Tuple input, BasicOutputCollector collector) {
		jedis = new Jedis("10.176.3.102", 6379);
		String Key = input.getString(0).trim();
		String len = String.valueOf(input.getString(0).length());
		Map<String,String> redisMap = new ConcurrentHashMap<String,String>();
		redisMap.put(Key, len);
		String[] strings = new String[redisMap.size()<<1];
		int i =0;
		for (String key : redisMap.keySet()) {
			strings[i] = key;
			strings[i+1]= redisMap.get(Key);
			i=i+2;
		}
		// 打印数据	
		Pipeline pipeline = jedis.pipelined();
		pipeline.select(10);
		pipeline.mset(strings);
		jedis.disconnect();
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// TODO Auto-generated method stub

	}

}
